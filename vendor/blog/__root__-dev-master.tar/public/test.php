<?php
namespace asdfdf\asdfsadf\dsafsdf {
    class /*sdfsadfd*/ classname { 
    }
}
class sdf {
}
namespace xfdf {
    class /*sdfsadfd*/
    }
}
adfasfd;
asdfsadf
odsfasodffasdf
if (sdf) {

}

class sdfs {

}
