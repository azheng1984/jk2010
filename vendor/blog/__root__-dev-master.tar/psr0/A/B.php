<?php
class A_B {
}
