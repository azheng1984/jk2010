if (hi) {
  var hello = 'hello';
}
