<?php
echo '.hi3 {
  color: #0066cc;
  background-color: #0066cc;
}';
