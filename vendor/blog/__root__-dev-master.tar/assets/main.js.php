var hi = "liset\"";
if (hi) {
     microtime(true);
}
