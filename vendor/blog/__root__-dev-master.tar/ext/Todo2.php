<?php
namespace Hyperframework\Blog\Ext;

class Todo2 {
    public function hi() {
        echo 'hi';
    }
    
}
