<?php
namespace Hyperframework\Blog;

class Ext_Todo2 {
    public function hi() {
        echo 'hi';
    }
}
