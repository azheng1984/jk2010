<?php
class Ns {
    public static function hi() {
echo 'echo';        
    }
}
