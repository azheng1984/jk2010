<?php
namespace Ns\Hi_L2;

class Todo {
    public static function name() {
        echo 'hi_l2 ns_todo!!';
    }
}
