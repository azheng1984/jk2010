<?php
namespace Ns\Hi\L2\L2_X;

class Todo {
    public static function name() {
        echo 'ns_todo';
    }
}
