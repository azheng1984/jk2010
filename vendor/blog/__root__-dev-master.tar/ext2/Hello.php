<?php
namespace Hyperframework\Blog\Ext;
class Hello {
    
}
