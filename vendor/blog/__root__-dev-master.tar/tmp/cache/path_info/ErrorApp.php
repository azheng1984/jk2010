<?php return array (
  '/' => 
  array (
    'views' => 
    array (
      'html' => 'Html',
    ),
    'namespace' => 'Hyperframework\\Blog\\ErrorApp',
  ),
)