<?php
namespace Hyperframework\Blog\App\Articles;

class Html {
    public function render() {
        echo 'hello';
    }
}
