<?php
namespace Hyperframework\Blog\App\Articles\Item\Comments;

class Html {
    public function render() {
        echo 'item!';
    }
}
