<?php
namespace Hyperframework\Blog\App\Articles;

class Json {
    public function render() {
        echo 'hi';
    }
}
