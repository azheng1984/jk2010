<?php
namespace Hyperframework\Blog\App\Articles;

class Action {
    public function get($param) {
        echo 'action!';
    }
}
