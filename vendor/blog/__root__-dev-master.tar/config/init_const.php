<?php
namespace Hyperframework\Blog;

define('HYPERFRAMEWORK_PATH', dirname(ROOT_PATH) . DIRECTORY_SEPARATOR .'hf'
    . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'lib');
