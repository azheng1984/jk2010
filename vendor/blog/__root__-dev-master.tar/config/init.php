<?php
return array(
    'hyperframework.asset.concatenate_manifest' => false,
    'hyperframework.asset.enable_versioning' => true,
    'hyperframework.asset.enable_proxy' => true,
//    'hyperframework.use_composer_class_loader' => true,
    'hyperframework.path_info.enable_cache' => false,
//    'hyperframework.class_loader.enable_zero_folder' => true,
);
